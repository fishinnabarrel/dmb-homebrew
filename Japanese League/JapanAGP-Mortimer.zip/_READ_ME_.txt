Important!!

Mortimer NPB All Time Greatest Players

The players on this league disk were created to be used with the Diamond Mind All Time Greatest Players Disk (MLB) (AGP2003/AGP2006/etc).

As such these players have been created using special formulas that will allow them to be used directly with the Major League Baseball Players of any Diamond Mind Baseball MLB player set. The stats displayed for each player are their actual Nippon baseball League stats, not normalized stats -- all normalization is done in the player creation process.

These players are not designed to be used in a Japanese-only league.  They are designed to be imported and drafted into a league with U.S. Major League baseball players.  These players have been normalized to play in the MLB. Absent Major Leaguers, these players will still perform _as if_ they were competing in the MLB.

I will release a different version of this set for Japanese League play only, but this is not it.

