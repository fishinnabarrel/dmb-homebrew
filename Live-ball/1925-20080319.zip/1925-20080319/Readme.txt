This is an All Time Team Greats League for Diamond Mind Baseball 7.0.  It is a league that I have maintained in various formats for several years now and offer to anyone who might enjoy it for free.  It contains what I feel are the best of the best players for all the "established" organizations in Major League Baseball.  It is a 'single season' type of league, where I have chosen the players single best season of his career to use.  My main criteria for selecting players is that he played the entire year with the same team and that year was the best single year of his career.

This is the final revision of this league in DMB 7 format.  Future updates will be done in the most current
version of DMB.

It contains 26 teams, with a minimum of 40 players per team.  (At least 24 positional players and 16 pitchers.)  It contains a 154 game schedule, 40 ballparks, and 40 ERA reference years.  It is updated with players through the 2000 season.  This revision of my league is the last version to be done in DMB v7.0.  I
have migrated it DMB 8.0 and plan to release future versions of my season disk in this format until a newer
version of DMB is released.

You'll note that the 4 most recent expansion teams are not included.  This is due to the fact that I have found it takes approximately 20 years of team history before you can begin to select enough players that have played for the team and had their best year with that team AND completely fill out the teams roster well enough to put forth a quality team.  Thus, it will be a few years yet before Colorado, Florida, Arizona, and Tampa Bay get into this season disk.

Some of the team names used are the older nostalgic names, such as Brooklyn Dodgers, Washington Senators, etc.

I feel the players & years for each player I have chosen for each team is accurate & correct.  I have put an enormous amount of time into this league over the years and I believe that you will absolutely love this season disk!

Please keep in mind all my hard work if you share this disk and give me credit.  Also keep in mind the copyrights of DMB.  You may not directly add player data from season disks they sell into this season disk and redistribute it.  All the work done in this season disk has been calculated and entered in manually by me.  (Yes, it was a lot of work!)  The exception is that several of the ballparks and ERA information stats from their Old Time disk they sell has been included for reference.  (This was done with DMB's approval, but no player data itself has been used in any form in this season disk.)

Installation instructions are found below.

Keith Hemmelman
khemmelman@home.com

http://members.home.net/hemmelman/


============
Installation
============

Start by creating a directory/folder under your Diamond Mind Baseball game directory/folder.  (i.e. - ..\dmb7\tmgrts)  The game directory is called c:\dmb7 on most computers, but may differ if you chose a different name when you installed the game.  Then extract the contents of this zip file into that newly-created directory.  You'll then need to tell Diamond Mind Baseball that there's a new season disk out there.  To do this, follow the instructions on pages 96-98 of the Version 7 User Guide. You'll be using the PlayerDir command to create a reference to this new directory/folder.
