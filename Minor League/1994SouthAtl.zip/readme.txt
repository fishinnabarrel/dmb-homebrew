The 1994 South Atlantic League.

Hi.  This is my first Diamond Mind season.  I hope that you find it enjoyable.  While I've spent many many hours preparing
this disk, I cannot vouch for 100% accuracy.  To the best of my knowledge,  all stats are correct and in order, 
all players on their correct teams, all ballparks correctly identifed, etc.
If by chance you find an error or correction, please contact me at the email address below and I'll update the files.   To use this season,
unzip the file into a directory under your Diamond Mind directory.

I chose this season and league for a couple reasons:  I'm a life-long Indians fan, and the closest team to my home (Montgomery, Alabama)
is the Columbus (Ga) Redstixx, an Indians Class A affiliate.  My family and I make the 75 mile trek four or five times a year to see who
is an up-and-comer in the Tribe's organization.  The Redstixx play at a wonderful old-time (but nicely renovated) park: Golden Park.  I
love the fact that I can take my family of four, sit in the first row behind the dugout, enjoy a great game, and spend less than $30 for
tickets.  Even better, I've seen many of the current stars of the Tribe and other teams when they were just starting out.  In 1994, the Redstixx
had current Indians (1999) Richie Sexson, Einar Diaz, Enrique Wilson, and Montreal pitcher Steve Kline.  The next season, Jaret Wright
made his debut in Columbus.  I saw Jaret pitch against Reid Ryan (Nolan's sun) that season.  The Redstixx weren't the only SAL team to
have some great prospects:  Other future major leaguers playing in the SAL in 1994:  Kevin Millwood, Reuben Rivera, Ricky Leddee,
Magglio Ordonez, Scott Rolen, Frank Catlanotto, Juan Encarnacion, Esteban Yan, Jermaine Dye, Alan Benes, Eli Marrero, Shannon Stewart, and quite a few others.  

You'll notice some interesting things about this league:  pitchers balk often, throw wild pitches often, and hit batters often.  Many of the young
arms coming into the league were all power and very little control.  Jeff Berblinger of Savannah was hit by the pitcher 25 times, Esteban
Yan of Macon committed 6 balks, and Alvin Brown hurled 27 wild pitches.  Lots of errors occur, and lots of games are decided by
bad play instead of good.  Such is baseball in the low minors.  Not always pretty, but quite often great fun.

I've set the opening day rosters at 40 players.  A lot of players saw limited playing time.  Lots
of roster changes occured in the low minors, so you'll have to keep an eye on usage,  even the computer will be tempted
to bat Jeff Abbott more often that he should!

The schedule is computer generated, and will play a 140-game season with DH.  The SAL acutally splits the season into two halves, but
I figured this schedule will be easy to use and give you the same results.

Most of all, I hope you enjoy this DMB season.  Pass it on freely to anyone interested.  I'll be creating other minor seasons in the
future, so keep in touch.

ENJOY IT!

Scott Parks, August 1999
siparks@bellsouth.net